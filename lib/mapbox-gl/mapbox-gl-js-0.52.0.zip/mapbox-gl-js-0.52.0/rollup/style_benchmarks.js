import './build/benchmarks/styles/chunk1';
import './build/benchmarks/styles/worker';
import './build/benchmarks/styles/benchmarks';
