
import spec from './v8.json';
export default spec;
