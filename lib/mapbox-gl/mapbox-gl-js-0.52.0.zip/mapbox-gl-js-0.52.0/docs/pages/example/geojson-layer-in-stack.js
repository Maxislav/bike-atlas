/*---
title: Add a new layer below labels
description: 'Using the second argument of [`addLayer`](/mapbox-gl-js/api/#map#addlayer), you can be more precise'
tags:
  - layers
pathname: /mapbox-gl-js/example/geojson-layer-in-stack/
---*/
import Example from '../../components/example';
import html from './geojson-layer-in-stack.html';
export default Example(html);
