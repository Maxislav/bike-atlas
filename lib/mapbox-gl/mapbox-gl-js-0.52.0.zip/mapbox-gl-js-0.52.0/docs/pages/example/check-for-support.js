/*---
title: Check for browser support
description: Check for Mapbox GL browser support
tags:
  - browser-support
pathname: /mapbox-gl-js/example/check-for-support/
---*/
import Example from '../../components/example';
import html from './check-for-support.html';
export default Example(html);
